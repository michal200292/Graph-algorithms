from data import runtests

def my_solve(N, M, K, base, wages, eq_cost):
    print(f"Artystów: {N}, pokazów: {K}, występy: {K}")
    for w in wages:
        for (show, cost) in w:
            # ...
            pass
    return 0

runtests(my_solve)
